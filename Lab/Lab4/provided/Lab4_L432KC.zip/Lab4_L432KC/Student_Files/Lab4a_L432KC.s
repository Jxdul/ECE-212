/*Author - Lab Tech. Last edited on Jan 14, 2022 */
/*-----------------DO NOT MODIFY--------*/
.global Welcomeprompt
.global printf
.global cr
.extern value
.extern getstring
.extern getchar
.extern putchar
.syntax unified

.text
Welcomeprompt:
/*--------------------------------------*/

/*-------Students write their code here ------------*/





















/*-----------------DO NOT MODIFY--------*/

.data
/*--------------------------------------*/

